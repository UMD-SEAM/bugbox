<?php

	//--- database configuration
	$DATABASE_HOST = 'DEFHOST';
	$DATABASE_DB = 'DEFDB';
	$DATABASE_PWD = 'DEFPWD';
	$DATABASE_UID = 'DEFUSERID';
?>
